import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

runApp(MyApp myApp) {
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Amajon Store',
      theme: ThemeData(),
      home: const ECommerceScreen(),
    );
  }
  
  Widget MaterialApp({required String title, required theme, required ECommerceScreen home}) {}
}

class ThemeData {
}

class BuildContext {
}

class Widget {
}

class Key {
}

class StatelessWidget {
}

class ECommerceScreen extends StatelessWidget {
  const ECommerceScreen({Key? key}) : super(key: key);
  
  get bottomNavigationBar => null;

  @override
  // ignore: override_on_non_overriding_member
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Amajon Store'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[

  // Banner Promo
            width: double.infinity,
  padding: const EdgeInsets.all(24.0),
  margin: const EdgeInsets.only(top: 16.0, left: 16.0, right: 16.0, bottom: 24.0),
  decoration: BoxDecoration(
    color: Colors.orange.shade100,
    borderRadius: BorderRadius.circular(12.0),
  ),
  child: const Text(
    'GRATIS ONGKIR untuk pembelian di atas Rp500.000!',
    textAlign: TextAlign.center,
    style: TextStyle(
      fontSize: 20.0,
      fontWeight: FontWeight.bold,
      color: Colors.deepOrange,
    ),
  ),
),

bottomNavigationBar : BottomNavigationBar(
    items: const [
      BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Beranda'),
      BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Akun'),
    ],
  ),
  floatingActionButton: FloatingActionButton(
    onPressed: () {},
    child: const Icon(Icons.shopping_cart),
  ),
);

// Produk 1
Container(
  margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
  padding: const EdgeInsets.only(top: 20.0, left: 24.0, right: 12.0, bottom: 16.0),
  decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(8.0),
      boxShadow: [
      BoxShadow(
        color: Colors.grey.withOpacity(0.5),
        spreadRadius: 2,
        blurRadius: 5,
        offset: const Offset(0, 3),
      ),
    ],
  ),
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
       const Text(
           'Sepatu Running',
            style: TextStyle(
              fontSize: 18.0,
              fontWeight: FontWeight.bold,
            ),
         ),   
      const SizedBox(height: 4.0),
      const Row(
        children: [
          Icon(Icons.star, color: Colors.amber, size: 16),
          SizedBox(width: 4),
          Text("4.7"),
        ],
      ),
      const SizedBox(height: 8.0),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          const Text(
            'Rp 750.000',
            style: TextStyle(
              color: Colors.blue,
              fontSize: 16.0,
            ),
          ),
          Container(
            padding: padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(4.0),
            ),
            child: const Center(
              child: Text(
                'Beli',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    ],
  ),
),

// Produk 2
Container(
  margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
  padding: const EdgeInsets.only(top: 20.0, left: 24.0, right: 12.0, bottom: 16.0),
  decoration: BoxDecoration(
                color: Colors.green.shade50,
    borderRadius: BorderRadius.circular(8.0),
    boxShadow: [
      BoxShadow(
        color: Colors.grey.withOpacity(0.5),
        spreadRadius: 2,
        blurRadius: 5,
        offset: const Offset(0, 3),
      ),
    ],
  ),
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      const Text(
        'Tas Ransel',
        style: TextStyle(
          fontSize: 18.0,
          fontWeight: FontWeight.bold,
        ),
      ),
      const SizedBox(height: 4.0),
      const Row(
        children: [
          Icon(Icons.star, color: Colors.amber, size: 16),
          SizedBox(width: 4),
          Text("4.3"),
        ],
      ),
      const SizedBox(height: 8.0),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          const Text(
            'Rp 350.000',
            style: TextStyle(
              color: Colors.blue,
              fontSize: 16.0,
            ),
          ),
          Container(
            padding: padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(4.0),
            ),
            child: const Center(
              child: Text(
                'Beli',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
      
    ],
  ),
),

// Kategori
Container(
                margin: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: const [
                        CategoryItem(icon: Icons.shopping_bag, label: 'Pakaian'),
                        CategoryItem(icon: Icons.watch, label: 'Aksesoris'),
                        CategoryItem(icon: Icons.devices, label: 'Elektronik'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: const [
                        CategoryItem(icon: Icons.sports_soccer, label: 'Olahraga'),
                        CategoryItem(icon: Icons.kitchen, label: 'Rumah'),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          );
        }


class CategoryItem extends StatelessWidget {
  final IconData icon;
  final String label;

  const CategoryItem({super.key, required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: Colors.blue),
        const SizedBox(height: 8.0),
        Text(label),
      ],
    );
  }
}
